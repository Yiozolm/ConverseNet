# 匹配训练流程耗时审计

Historical 3 seeds x before/current x 4000 identical updates; seven sessions; no rerun or causal hardware attribution.

同一种子按数据哈希及更新编号配对；模型初始化、配方、4000 个 loss/梯度范数均一致。历史失败及恢复成本保留。

下表单位秒，正值表示 current 更慢。外层各项互斥；训练步子项另表展开，不重复加入总计。

| Seed | 初始化（扣初始保存） | 数据准备/哈希 | 训练步 | 评估主体 | 全部保存 | 未归因余量 | 进程总差 |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 17 | -0.746056 | +0.650353 | +22.087623 | -11.968693 | -0.004990 | +0.468812 | +10.487048 |
| 29 | +0.256877 | +0.045208 | +74.969736 | -8.813913 | -0.029753 | -1.621792 | +64.806362 |
| 43 | -2.818818 | +7.874579 | +143.087675 | -7.599282 | -0.029572 | +0.816796 | +141.331378 |

| Seed | H2D | 前向+loss+backward | 有限性/梯度范数 | Adam | 步内未归因余量 |
|---:|---:|---:|---:|---:|---:|
| 17 | +0.066908 | +18.593408 | +2.019801 | +1.407171 | +0.000335 |
| 29 | +0.030068 | +73.598767 | +0.685922 | +0.793986 | -0.139007 |
| 43 | +0.108968 | +132.268526 | +5.053926 | +5.344366 | +0.311888 |

## 计时边界

- Each outer partition closes to the worker process timer, starting in main after module imports. Interpreter/wrapper startup and final report write are excluded.
- Initial checkpoint is subtracted from setup before all checkpoints are included once. Failed-prefix and recovery process timers both remain included.
- Step subphases are sequential and explicitly synchronized by the worker; their sum is nested in training_step and never added to it.
- CUDA event spans include gaps/CPU submission delays, not only GPU kernels. Wall and event timers are never added together.
- Data is synchronous CPU generation/validation/hash, not an asynchronous DataLoader wait measurement. H2D is inside the step.
- Evaluation body excludes its prechecks/cache setup and cleanup; these, logging, metadata and unmeasured checks remain unattributed.
- The 282.197191 second recovery restart interval is separate from process timers and is not added to this ledger.
- Optimizer work and scheduled evaluation counts match. Recovery adds setup and an initial checkpoint, retained as actual cost.
- Chronological processes were not interleaved benchmarks; stage attribution cannot prove clocks, temperature, contention or a code regression caused the differences.

机器报告包含每个 session 的完整账本、每 250 步分块统计及输入 SHA。本审计解释时间落在哪个阶段，不把进程顺序与时间漂移推断为优化代码的因果效应。
