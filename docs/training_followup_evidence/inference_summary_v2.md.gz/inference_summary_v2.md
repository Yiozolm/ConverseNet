## 完整 GPU 测量结果

本次独占 GPU 进程正常退出，wrapper wall 236.065 秒；16/16 个 case/mode 完整完成。
模型值/version/绑定、source/binary、每轮亲和性检查通过。所有配对 eager 输出、capture-context controls、布局 fallback 与 Graph 生命周期门槛通过。

每个完整 forward 均实际记录70次既有生产 LayerNorm dispatch、35次padding后的prior和5次DataNet。
原始 caller 比较保留了8个no_grad case在两个route中的Graph/eager字节差异（16项）；8个inference_mode case则在两个route中均相等。
因此不能把Graph表述成原no_grad eager的逐字节替代；这里的严格Graph gate使用相同inference tensor、contiguous clone及缓存资格。

下表时间均为毫秒，`旧→生产`是各route的7轮wall中位数；倍数是逐paired round旧/生产比值的中位数，所以不必等于两列中位数直接相除。

| Case / mode | 完整 eager 旧→生产 | disabled runner 旧→生产 | Graph hit 旧→生产 | paired eager / Graph 倍数 |
|---|---:|---:|---:|---:|
| b1_even_s3/no_grad | 28.615→21.834 | 27.980→21.370 | 15.549→13.734 | 1.316 / 1.130 |
| b1_even_s3/inference_mode | 26.429→20.219 | 25.859→19.491 | 15.641→13.696 | 1.315 / 1.132 |
| b4_even_s3/no_grad | 70.513→63.721 | 70.782→63.310 | 65.854→59.355 | 1.114 / 1.107 |
| b4_even_s3/inference_mode | 70.686→62.662 | 70.727→62.656 | 64.740→59.236 | 1.130 / 1.093 |
| b1_odd_s3/no_grad | 36.266→30.209 | 32.123→30.181 | 23.872→22.684 | 1.206 / 1.052 |
| b1_odd_s3/inference_mode | 36.550→29.739 | 33.606→27.567 | 23.856→22.681 | 1.224 / 1.050 |
| b4_odd_s3/no_grad | 102.496→95.543 | 102.706→95.208 | 96.990→90.743 | 1.072 / 1.070 |
| b4_odd_s3/inference_mode | 103.200→94.793 | 102.173→94.964 | 95.979→90.909 | 1.086 / 1.057 |
| b1_medium_s3/no_grad | 81.026→73.732 | 81.161→73.392 | 74.799→69.826 | 1.095 / 1.073 |
| b1_medium_s3/inference_mode | 80.469→72.932 | 80.788→72.892 | 74.935→69.233 | 1.106 / 1.092 |
| b1_scale4_generic/no_grad | 28.518→21.770 | 28.698→21.097 | 16.809→14.954 | 1.310 / 1.130 |
| b1_scale4_generic/inference_mode | 27.348→20.952 | 26.309→19.828 | 16.889→15.076 | 1.321 / 1.120 |
| b1_odd_strided/no_grad | 36.223→30.077 | 33.321→29.176 | 24.002→22.705 | 1.199 / 1.056 |
| b1_odd_strided/inference_mode | 36.329→29.911 | 33.669→29.829 | 23.801→22.703 | 1.216 / 1.058 |
| b4_channels_last_shared/no_grad | 70.187→63.565 | 70.414→62.818 | 65.175→58.826 | 1.107 / 1.098 |
| b4_channels_last_shared/inference_mode | 70.318→62.703 | 70.062→63.138 | 64.169→59.771 | 1.121 / 1.071 |

这些逐case的paired wall中位数在完整eager为 1.072–1.321×，Graph hit为 1.050–1.132×。
这是所测shape的观测范围，没有线上流量权重，不计算或声称整体部署收益；完整逐轮比值、CUDA event span和allocated peak增量保留在JSON。

### 初始化进程中的 setup 观测

下列每项是一次完整调用wall观测，单位毫秒，旧→生产。cuFFT/cuDNN/CUDA进程已初始化；不称为冷进程启动时间，也不与warm中位数合并。

| Case / mode | 空 eager spectrum cache | 首次 runner capture | LRU miss | clear/recapture |
|---|---:|---:|---:|---:|
| b1_even_s3/no_grad | 60.435→24.157 | 94.225→79.713 | 109.773→104.087 | 96.427→75.878 |
| b1_even_s3/inference_mode | 55.648→20.021 | 95.047→75.556 | 122.692→95.033 | 92.239→74.574 |
| b4_even_s3/no_grad | 71.903→63.860 | 243.782→207.443 | 345.890→317.960 | 239.006→209.546 |
| b4_even_s3/inference_mode | 71.389→63.637 | 238.723→200.338 | 330.317→318.883 | 239.079→208.749 |
| b1_odd_s3/no_grad | 56.841→29.282 | 114.445→101.495 | 123.576→99.925 | 121.105→103.420 |
| b1_odd_s3/inference_mode | 53.063→28.733 | 114.135→101.895 | 120.946→99.509 | 122.486→105.768 |
| b4_odd_s3/no_grad | 106.026→97.202 | 334.266→310.824 | 341.485→319.804 | 334.097→304.813 |
| b4_odd_s3/inference_mode | 103.749→96.705 | 331.824→305.126 | 341.665→315.309 | 330.786→301.718 |
| b1_medium_s3/no_grad | 84.168→76.954 | 273.708→248.604 | 345.020→328.806 | 278.305→246.490 |
| b1_medium_s3/inference_mode | 84.202→76.328 | 250.735→217.500 | 313.857→289.247 | 283.228→249.773 |
| b1_scale4_generic/no_grad | 61.070→22.096 | 103.205→73.950 | 99.968→79.105 | 100.018→79.874 |
| b1_scale4_generic/inference_mode | 54.375→20.524 | 96.358→73.684 | 95.803→79.306 | 101.341→74.793 |
| b1_odd_strided/no_grad | 55.833→28.987 | 112.771→103.219 | 120.642→100.196 | 116.551→98.412 |
| b1_odd_strided/inference_mode | 54.150→28.637 | 117.755→102.313 | 122.486→101.418 | 121.091→101.520 |
| b4_channels_last_shared/no_grad | 71.073→63.429 | 237.616→206.317 | 345.223→314.859 | 237.166→209.227 |
| b4_channels_last_shared/inference_mode | 69.584→63.394 | 237.145→208.060 | 342.896→317.303 | 242.592→209.132 |

首次runner时间包含warmup2、capture、copy、replay及output clone；它与已命中的runner是不同口径。显存数据是live state之上的allocated peak增量，不能当作总VRAM或跨shape容量上限。
