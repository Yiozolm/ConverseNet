# Nearest phase repair: original matrix gate

Result: **candidate_failed_numeric_gate**. CPU/CUDA minimal forward checks pass, but performance and production remain blocked.

- Original historical error dictionaries and pass flags: **96/96 exactly replayed**.
- Old failures: **45/96**. New failures: **45/96**.
- Transitions: **48 pass→pass,3 pass→fail,3 fail→pass,42 fail→fail**.
- Independently decoded and SHA-checked536 new tensor byte records; recomputed192 old/new error dictionaries plus96 Python32-reference dictionaries on CPU.

| Tensor | Old failures | New failures | Pass→fail | Fail→pass |
|---|---:|---:|---:|---:|
| output0 | 17 | 17 | 0 | 0 |
| dx | 17 | 15 | 0 | 2 |
| dweight | 7 | 8 | 2 | 1 |
| dbias | 4 | 5 | 1 | 0 |

| Changed outcome | Case | Seed | Tensor | Scale | KB/KC | Weak |
|---|---:|---:|---|---:|---|---|
| pass_to_fail | 8 | 41199 | dweight | 3 | 1/1 | False |
| pass_to_fail | 10 | 41201 | dweight | 3 | 1/3 | False |
| fail_to_pass | 11 | 41202 | dx | 3 | 1/3 | True |
| pass_to_fail | 16 | 41207 | dbias | 4 | 1/1 | False |
| fail_to_pass | 18 | 41209 | dweight | 4 | 1/3 | False |
| fail_to_pass | 23 | 41214 | dx | 4 | 2/3 | True |

The documented minimal forward counterexample is repaired on CPU/CUDA, but the full original96-tensor zero-margin gate still rejects45 tensors. Three regressions and three improvements do not cancel or rescue admission. All tensor hashes/bytes are new measurements, never invented historical hashes.

The original research files/artifact and production sources were not modified. Gate exit code4 represents numerical rejection. No performance run followed.
